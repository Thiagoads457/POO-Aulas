﻿using HerancaFuncionario;

Funcionario f = new Funcionario(001,"Thiago",1000);
f.Mostrar();

Horista h = new Horista(002,"João",1500,15);
h.Mostrar();


Mensalista m = new Mensalista(003,"Diana",2000,20);
m.Mostrar();
